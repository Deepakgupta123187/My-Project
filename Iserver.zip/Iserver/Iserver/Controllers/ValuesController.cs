﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
//using Iserver.model;

namespace Iserver.Controllers
{
//    [Authorize]
    [Route("api/[controller]")]
    [ApiController]
    public class ValuesController : ControllerBase
    {
        private readonly ApplicationDBContext _db;

        public ValuesController(ApplicationDBContext db)
        {
            _db = db;
        }
        [HttpGet]
        public async Task<ActionResult<IEnumerable<identity>>> GetEmployees()
        {
            return await _db.identities.ToListAsync();
        }

        [HttpPost]
        public async Task<ActionResult<identity>> Postidentity([FromForm] identity identity)
        {
            _db.identities.Add(identity);
            await _db.SaveChangesAsync();

            return CreatedAtAction("Getidentity", new { id = identity.Id }, identity);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<identity>> Getidentity(int id)
        {
            var identity = await _db.identities.FindAsync(id);
            return Ok(identity);
        }


        [HttpPut("{id}")]
        public async Task<IActionResult> Putidentitye(int id, identity identity)
        {

            _db.Update(identity);
            await _db.SaveChangesAsync();

            return Ok();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> deleteidentity(int id)
        {
            var identity = await _db.identities.FindAsync(id);

            _db.identities.Remove(identity);
            await _db.SaveChangesAsync();

            return Ok();
        }

        private bool identityExists(int id)
        {
            return _db.identities.Any(e => e.Id == id);
        }
    }
}